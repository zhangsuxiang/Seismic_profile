# utility_functions.py
# 额外的实用工具函数，用于数据分析和可视化优化

import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde
import os

def analyze_data_distribution(data_file, output_dir='analysis_results'):
    """分析速度数据的分布特征"""
    
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    # 读取数据
    D = np.loadtxt(data_file)
    lon = D[:, 0]
    lat = D[:, 1] 
    dep = D[:, 2]
    val = D[:, 3]
    
    # 创建分析图
    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    fig.suptitle('Vp/Vs Data Distribution Analysis', fontsize=16)
    
    # 1. Vp/Vs直方图
    ax = axes[0, 0]
    ax.hist(val, bins=50, color='skyblue', edgecolor='black', alpha=0.7)
    ax.axvline(val.mean(), color='red', linestyle='--', label=f'Mean: {val.mean():.3f}')
    ax.axvline(np.median(val), color='green', linestyle='--', label=f'Median: {np.median(val):.3f}')
    ax.set_xlabel('Vp/Vs')
    ax.set_ylabel('Frequency')
    ax.set_title('Vp/Vs Distribution')
    ax.legend()
    
    # 2. 深度分布
    ax = axes[0, 1]
    ax.hist(dep, bins=30, color='coral', edgecolor='black', alpha=0.7, orientation='horizontal')
    ax.set_ylabel('Depth (km)')
    ax.set_xlabel('Frequency')
    ax.set_title('Depth Distribution')
    ax.invert_yaxis()
    
    # 3. 空间分布（散点图）
    ax = axes[0, 2]
    scatter = ax.scatter(lon, lat, c=val, cmap='jet_r', s=20, alpha=0.6)
    ax.set_xlabel('Longitude')
    ax.set_ylabel('Latitude')
    ax.set_title('Spatial Distribution')
    plt.colorbar(scatter, ax=ax, label='Vp/Vs')
    
    # 4. Vp/Vs vs 深度
    ax = axes[1, 0]
    scatter = ax.scatter(val, dep, c=val, cmap='jet_r', s=10, alpha=0.5)
    ax.set_xlabel('Vp/Vs')
    ax.set_ylabel('Depth (km)')
    ax.set_title('Vp/Vs vs Depth')
    ax.invert_yaxis()
    
    # 添加深度分层平均值
    depth_bins = np.arange(0, 26, 5)
    for i in range(len(depth_bins)-1):
        mask = (dep >= depth_bins[i]) & (dep < depth_bins[i+1])
        if np.sum(mask) > 0:
            mean_val = val[mask].mean()
            ax.plot([mean_val, mean_val], [depth_bins[i], depth_bins[i+1]], 
                   'r-', linewidth=3, alpha=0.8)
    
    # 5. 数据密度图
    ax = axes[1, 1]
    try:
        xy = np.vstack([lon, lat])
        z = gaussian_kde(xy)(xy)
        idx = z.argsort()
        lon_sorted, lat_sorted, z_sorted = lon[idx], lat[idx], z[idx]
        scatter = ax.scatter(lon_sorted, lat_sorted, c=z_sorted, s=20, alpha=0.6, cmap='hot')
        ax.set_xlabel('Longitude')
        ax.set_ylabel('Latitude')
        ax.set_title('Data Density')
        plt.colorbar(scatter, ax=ax, label='Density')
    except:
        ax.text(0.5, 0.5, 'Density calculation failed', 
               transform=ax.transAxes, ha='center')
    
    # 6. 统计信息
    ax = axes[1, 2]
    ax.axis('off')
    stats_text = f"""
    Data Statistics:
    ---------------
    Total points: {len(val)}
    
    Vp/Vs:
    Range: {val.min():.3f} - {val.max():.3f}
    Mean: {val.mean():.3f}
    Std: {val.std():.3f}
    25%: {np.percentile(val, 25):.3f}
    50%: {np.percentile(val, 50):.3f}
    75%: {np.percentile(val, 75):.3f}
    
    Depth:
    Range: {dep.min():.1f} - {dep.max():.1f} km
    
    Spatial:
    Lon: {lon.min():.3f} - {lon.max():.3f}
    Lat: {lat.min():.3f} - {lat.max():.3f}
    """
    ax.text(0.1, 0.9, stats_text, transform=ax.transAxes, 
           fontsize=10, verticalalignment='top', fontfamily='monospace')
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, 'data_distribution_analysis.png'), 
                dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"数据分析完成，结果保存在 {output_dir}")
    return val.mean(), val.std(), len(val)


def create_profile_location_map(profiles, data_file=None, output_file='profile_locations.png'):
    """创建剖面位置图"""
    
    fig, ax = plt.subplots(figsize=(10, 10))
    
    # 如果提供了数据文件，绘制数据点作为背景
    if data_file and os.path.exists(data_file):
        D = np.loadtxt(data_file)
        lon = D[:, 0]
        lat = D[:, 1]
        val = D[:, 3]
        
        # 绘制数据点
        scatter = ax.scatter(lon, lat, c=val, cmap='jet_r', s=5, alpha=0.3)
        plt.colorbar(scatter, ax=ax, label='Vp/Vs', shrink=0.8)
    
    # 绘制剖面线
    colors = plt.cm.rainbow(np.linspace(0, 1, len(profiles)))
    
    for i, profile in enumerate(profiles):
        # 绘制剖面线
        ax.plot([profile['lonA'], profile['lonB']], 
               [profile['latA'], profile['latB']], 
               color=colors[i], linewidth=3, label=profile.get('name', f'Profile {i+1}'))
        
        # 标记起点和终点
        ax.plot(profile['lonA'], profile['latA'], 'o', 
               color=colors[i], markersize=10, markeredgecolor='black')
        ax.plot(profile['lonB'], profile['latB'], 's', 
               color=colors[i], markersize=10, markeredgecolor='black')
        
        # 添加标签
        ax.text(profile['lonA'], profile['latA'], 'A', 
               fontsize=12, fontweight='bold', ha='right')
        ax.text(profile['lonB'], profile['latB'], "A'", 
               fontsize=12, fontweight='bold', ha='left')
    
    ax.set_xlabel('Longitude (°E)', fontsize=12)
    ax.set_ylabel('Latitude (°N)', fontsize=12)
    ax.set_title('Profile Locations', fontsize=16)
    ax.grid(True, alpha=0.3)
    ax.legend()
    
    # 设置坐标轴范围
    if data_file and os.path.exists(data_file):
        ax.set_xlim(lon.min() - 0.1, lon.max() + 0.1)
        ax.set_ylim(lat.min() - 0.1, lat.max() + 0.1)
    
    plt.tight_layout()
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"剖面位置图已保存: {output_file}")


def extract_profile_data(data_file, lonA, latA, lonB, latB, buffer_km=10, 
                        output_file='profile_data.txt'):
    """提取剖面附近的数据点并保存"""
    
    # 读取数据
    D = np.loadtxt(data_file)
    lon = D[:, 0]
    lat = D[:, 1]
    dep = D[:, 2]
    val = D[:, 3]
    
    # 计算剖面方向
    profile_vec = np.array([lonB - lonA, latB - latA])
    profile_length = np.linalg.norm(profile_vec)
    profile_unit = profile_vec / profile_length
    perp_unit = np.array([-profile_unit[1], profile_unit[0]])
    
    # 选择剖面附近的点
    selected_data = []
    
    for i in range(len(lon)):
        point_vec = np.array([lon[i] - lonA, lat[i] - latA])
        proj_dist = np.dot(point_vec, profile_unit)
        perp_dist = abs(np.dot(point_vec, perp_unit))
        perp_dist_km = perp_dist * 111
        
        if (0 <= proj_dist <= profile_length) and (perp_dist_km <= buffer_km):
            # 计算沿剖面的距离（km）
            dist_km = proj_dist * 111
            selected_data.append([dist_km, dep[i], val[i], lon[i], lat[i]])
    
    selected_data = np.array(selected_data)
    
    # 保存数据
    header = "Distance_km Depth_km Vp/Vs Longitude Latitude"
    np.savetxt(output_file, selected_data, header=header, fmt='%.6f')
    
    print(f"提取了 {len(selected_data)} 个数据点")
    print(f"数据已保存到: {output_file}")
    
    return selected_data


def compare_profiles(profile_data_list, labels, output_file='profile_comparison.png'):
    """比较多条剖面的Vp/Vs分布"""
    
    fig, axes = plt.subplots(len(profile_data_list), 1, 
                            figsize=(12, 4*len(profile_data_list)), 
                            sharex=True)
    
    if len(profile_data_list) == 1:
        axes = [axes]
    
    for i, (data, label) in enumerate(zip(profile_data_list, labels)):
        ax = axes[i]
        
        # 创建散点图
        scatter = ax.scatter(data[:, 0], -data[:, 1], c=data[:, 2], 
                           cmap='jet_r', s=20, vmin=1.68, vmax=1.83)
        
        ax.set_ylabel('Depth (km)', fontsize=12)
        ax.set_title(label, fontsize=14)
        ax.grid(True, alpha=0.3)
        ax.set_ylim(-25, 0)
        
        # 添加色标
        cbar = plt.colorbar(scatter, ax=ax)
        cbar.set_label('Vp/Vs', fontsize=12)
    
    axes[-1].set_xlabel('Distance (km)', fontsize=12)
    
    plt.tight_layout()
    plt.savefig(output_file, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"剖面对比图已保存: {output_file}")


# 使用示例
if __name__ == "__main__":
    # 1. 分析数据分布
    print("分析数据分布...")
    mean_val, std_val, n_points = analyze_data_distribution('Vpvs.xyz')
    
    # 2. 创建剖面位置图
    print("\n创建剖面位置图...")
    profiles = [
        {
            'name': 'Profile AA\'',
            'lonA': 117.759, 'latA': 39.2413,
            'lonB': 118.527, 'latB': 39.82
        }
    ]
    create_profile_location_map(profiles, 'Vpvs.xyz')
    
    # 3. 提取剖面数据
    print("\n提取剖面数据...")
    profile_data = extract_profile_data(
        'Vpvs.xyz',
        117.759, 39.2413,
        118.527, 39.82,
        buffer_km=15
    )
    
    print("\n工具函数测试完成！")