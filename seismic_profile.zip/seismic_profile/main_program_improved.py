import numpy as np
import matplotlib.pyplot as plt
from improved_surfer_profile import improved_surfer_profile

def add_geological_features(ax, max_dist):
    """添加地质构造特征标记"""
    
    # 只添加深度标记线
    depth_marks = [5, 10, 15, 20]
    for depth in depth_marks:
        ax.axhline(y=-depth, color='gray', linestyle=':', alpha=0.3, linewidth=0.5)
    
    return ax


def add_seismic_events(ax, event_file=None):
    """添加地震事件标记（可选）"""
    if event_file and os.path.exists(event_file):
        try:
            events = np.loadtxt(event_file)
            # 假设格式：[lon, lat, depth, magnitude]
            # 这里需要根据实际文件格式调整
            pass
        except:
            pass
    
    # 也可以手动添加重要地震事件
    # 示例：添加几个标志性地震
    example_events = [
        {'dist': 15, 'depth': 8, 'mag': 3.5, 'label': 'M3.5'},
        {'dist': 32, 'depth': 12, 'mag': 4.2, 'label': 'M4.2'},
    ]
    
    for event in example_events:
        ax.plot(event['dist'], -event['depth'], '*', 
               markersize=10 + event['mag']*2, 
               markerfacecolor='yellow', 
               markeredgecolor='red', 
               markeredgewidth=1.5)
        ax.text(event['dist'], -event['depth']-1, event['label'], 
               fontsize=9, ha='center', fontweight='bold')


def create_multi_profile_comparison(profiles_config):
    """创建多条剖面的对比图（可选功能）"""
    n_profiles = len(profiles_config)
    fig, axes = plt.subplots(n_profiles, 1, figsize=(14, 5*n_profiles), 
                            sharex=True)
    
    if n_profiles == 1:
        axes = [axes]
    
    for i, config in enumerate(profiles_config):
        # 调用主函数绘制每条剖面
        # 这里需要根据实际需求实现
        pass
    
    return fig, axes


# ================ 主程序 ================
if __name__ == "__main__":
    
    # 设置matplotlib参数以获得更好的显示效果
    plt.rcParams['font.size'] = 12
    plt.rcParams['axes.linewidth'] = 1.5
    plt.rcParams['xtick.major.width'] = 1.5
    plt.rcParams['ytick.major.width'] = 1.5
    plt.rcParams['xtick.major.size'] = 6
    plt.rcParams['ytick.major.size'] = 6
    
    # 如果有中文显示需求，设置中文字体
    # plt.rcParams['font.sans-serif'] = ['SimHei']  # Windows
    # plt.rcParams['font.sans-serif'] = ['Arial Unicode MS']  # macOS
    plt.rcParams['axes.unicode_minus'] = False
    
    # 1. 定义剖面参数
    profile_params = {
        'data_file': 'Vpvs.xyz',                # 速度数据文件
        'fluid_file': '流体超压地震.txt',        # 流体超压地震数据文件
        'lonA': 117.759,                        # A点经度
        'latA': 39.2413,                        # A点纬度
        'lonB': 118.527,                        # B点经度  
        'latB': 39.82,                          # B点纬度
        'nx': 300,                              # 水平网格数（提高分辨率）
        'nz': 150,                              # 垂直网格数（提高分辨率）
        'buffer_km': 10                         # 剖面缓冲区宽度
    }
    
    # 2. 调用改进的函数绘制剖面
    print("=" * 50)
    print("开始绘制地球物理速度剖面")
    print("=" * 50)
    
    fig, ax = improved_surfer_profile(**profile_params)
    
    # 3. 添加额外的地质构造标记
    print("添加地质构造特征...")
    max_dist = np.sqrt((profile_params['lonB'] - profile_params['lonA'])**2 + 
                      (profile_params['latB'] - profile_params['latA'])**2) * 111
    add_geological_features(ax, max_dist)
    
    # 4. 添加地震事件（如果有额外的地震目录）
    # add_seismic_events(ax, 'earthquake_catalog.txt')
    
    # 5. 添加剖面位置信息文本
    info_text = (f"Profile: A({profile_params['lonA']:.3f}°E, {profile_params['latA']:.3f}°N) → "
                f"A'({profile_params['lonB']:.3f}°E, {profile_params['latB']:.3f}°N)\n"
                f"Length: {max_dist:.1f} km")
    ax.text(0.02, 0.98, info_text, transform=ax.transAxes, 
            fontsize=10, verticalalignment='top',
            bbox=dict(boxstyle="round,pad=0.5", facecolor='white', 
                     edgecolor='gray', alpha=0.8))
    
    # 6. 调整布局
    plt.tight_layout()
    
    # 7. 保存图片
    print("\n保存图片...")
    # 高分辨率PNG
    plt.savefig('improved_seismic_profile_high_res.png', dpi=600, 
                bbox_inches='tight', facecolor='white')
    print("已保存: improved_seismic_profile_high_res.png (600 DPI)")
    
    # 标准分辨率PNG
    plt.savefig('improved_seismic_profile.png', dpi=300, 
                bbox_inches='tight', facecolor='white')
    print("已保存: improved_seismic_profile.png (300 DPI)")
    
    # 矢量格式
    plt.savefig('improved_seismic_profile.pdf', bbox_inches='tight', 
                facecolor='white')
    print("已保存: improved_seismic_profile.pdf (矢量格式)")
    
    # 8. 生成数据质量报告（可选）
    print("\n" + "=" * 50)
    print("数据质量报告：")
    print("=" * 50)
    
    # 读取原始数据进行统计
    D = np.loadtxt(profile_params['data_file'])
    val = D[:, 3]
    
    print(f"原始数据点数: {len(val)}")
    print(f"Vp/Vs 范围: {val.min():.3f} - {val.max():.3f}")
    print(f"Vp/Vs 平均值: {val.mean():.3f}")
    print(f"Vp/Vs 标准差: {val.std():.3f}")
    
    # 计算剖面覆盖率
    print(f"\n剖面参数:")
    print(f"剖面长度: {max_dist:.1f} km")
    print(f"网格分辨率: {profile_params['nx']} × {profile_params['nz']}")
    print(f"缓冲区宽度: {profile_params['buffer_km']} km")
    
    # 9. 显示图形
    print("\n显示图形...")
    plt.show()
    
    print("\n程序执行完成！")
    
    
# ================ 批处理多条剖面（可选扩展）================
def batch_process_profiles():
    """批量处理多条剖面的示例函数"""
    
    # 定义多条剖面
    profiles = [
        {
            'name': 'Profile_AA',
            'lonA': 117.759, 'latA': 39.2413,
            'lonB': 118.527, 'latB': 39.82
        },
        {
            'name': 'Profile_BB',
            'lonA': 117.5, 'latA': 39.0,
            'lonB': 118.8, 'latB': 39.5
        },
        # 可以添加更多剖面
    ]
    
    # 批量处理
    for i, profile in enumerate(profiles):
        print(f"\n处理剖面 {i+1}/{len(profiles)}: {profile['name']}")
        
        fig, ax = improved_surfer_profile(
            'Vpvs.xyz',
            '流体超压地震.txt',
            profile['lonA'], profile['latA'],
            profile['lonB'], profile['latB']
        )
        
        # 保存每条剖面
        plt.savefig(f"{profile['name']}.png", dpi=300, bbox_inches='tight')
        plt.close()
    
    print("\n批处理完成！")


# 如果需要批处理，取消下面的注释
# batch_process_profiles()