import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import Rbf, griddata
from scipy.ndimage import gaussian_filter
from matplotlib.patches import Rectangle
from matplotlib.colors import LinearSegmentedColormap
import matplotlib.patches as patches

def improved_surfer_profile(data_file, fluid_file, lonA, latA, lonB, latB, 
                           nx=300, nz=150, buffer_km=10):
    """
    改进的地球物理速度剖面绘制函数
    
    参数:
    - data_file: 速度数据文件路径 [lon, lat, depth, value]
    - fluid_file: 流体超压地震数据文件路径
    - lonA, latA: 剖面起点 A 的经纬度
    - lonB, latB: 剖面终点 B 的经纬度
    - nx: 水平网格点数（增加到300以提高分辨率）
    - nz: 垂直网格点数（增加到150以提高分辨率）
    - buffer_km: 剖面缓冲区宽度（km）
    """
    
    # 1. 读取原始散点数据
    print("读取速度数据...")
    D = np.loadtxt(data_file)
    lon_raw = D[:, 0]
    lat_raw = D[:, 1]
    dep_raw = D[:, 2]
    val_raw = D[:, 3]
    
    # 2. 数据预处理和质量控制
    print("数据预处理...")
    lon, lat, dep, val = preprocess_data(lon_raw, lat_raw, dep_raw, val_raw)
    
    # 3. 选择剖面附近的数据点
    print("选择剖面附近的数据点...")
    selected_idx = select_profile_data(lon, lat, lonA, latA, lonB, latB, buffer_km)
    
    if len(selected_idx) == 0:
        print("警告：剖面附近没有找到数据点！")
        selected_idx = np.arange(len(lon))  # 使用所有数据
    
    lon = lon[selected_idx]
    lat = lat[selected_idx]
    dep = dep[selected_idx]
    val = val[selected_idx]
    
    print(f"选中 {len(lon)} 个数据点进行插值")
    
    # 4. 构造剖面网格
    lons = np.linspace(lonA, lonB, nx)
    lats = np.linspace(latA, latB, nx)
    deps = np.linspace(0, 25, nz)
    
    # 创建网格
    lon_grid, dep_grid = np.meshgrid(lons, deps)
    lat_grid = np.tile(lats, (nz, 1))
    
    # 5. 改进的3D插值
    print("执行改进的3D插值...")
    V = perform_improved_interpolation(lon, lat, dep, val, 
                                     lon_grid, lat_grid, dep_grid)
    
    # 6. 自适应平滑
    print("应用自适应平滑...")
    V = adaptive_smoothing(V, dep_grid)
    
    # 7. 计算剖面距离
    dist = calculate_profile_distance(lonA, latA, lons, lats)
    max_d = dist[-1]
    
    # 8. 创建图形
    fig = plt.figure(figsize=(14, 6), facecolor='white')
    ax = fig.add_axes([0.08, 0.15, 0.78, 0.75])
    
    # 9. 使用自定义色标绘制速度场
    cmap_custom = create_custom_colormap()
    vmin, vmax = 1.68, 1.83
    levels = np.linspace(vmin, vmax, 100)
    
    cf = ax.contourf(dist, -deps, V, levels=levels, cmap=cmap_custom, 
                     extend='both', vmin=vmin, vmax=vmax)
    
    # 10. 添加优化的等值线
    clevs = np.array([1.68, 1.70, 1.72, 1.74, 1.76, 1.78, 1.80, 1.82, 1.83])
    cs = ax.contour(dist, -deps, V, levels=clevs, colors='k', linewidths=0.4)
    
    # 只标注关键等值线
    clabel_levels = [1.72, 1.76, 1.80]
    ax.clabel(cs, levels=clabel_levels, inline=True, fontsize=8, 
              fmt='%.2f', inline_spacing=10)
    
    # 11. 标记剖面两端
    ax.plot([0, dist[-1]], [0, 0], 'k-', linewidth=2.5)
    ax.text(0, 1.5, 'A', verticalalignment='bottom', fontsize=16, 
            fontweight='bold', bbox=dict(boxstyle="round,pad=0.3", 
                                       facecolor='white', edgecolor='black'))
    ax.text(dist[-1], 1.5, "A'", verticalalignment='bottom', fontsize=16, 
            fontweight='bold', bbox=dict(boxstyle="round,pad=0.3", 
                                       facecolor='white', edgecolor='black'))
    
    # 12. 添加流体超压地震投影（可选）
    add_fluid_pressure_events(ax, fluid_file, lonA, latA, lonB, latB, max_d)
    
    
    # 13. 设置轴属性
    ax.set_xlabel('Distance (km)', fontsize=14, fontweight='bold')
    ax.set_ylabel('Depth (km)', fontsize=14, fontweight='bold')
    ax.set_xlim(0, dist[-1])
    ax.set_ylim(-25, 0)
    ax.grid(True, alpha=0.3, linestyle='--', linewidth=0.5)
    ax.tick_params(axis='both', which='major', labelsize=12)
    
    
    # 14. 添加主色标（Vp/Vs）
    cbar1 = plt.colorbar(cf, ax=ax, orientation='horizontal', pad=0.15,
                        shrink=0.8, aspect=30)
    cbar1.set_label('Vp/Vs', fontsize=14, fontweight='bold')
    cbar1.ax.tick_params(labelsize=11)
    cbar1.set_ticks(np.arange(1.68, 1.84, 0.02))
    
    # 15. 添加流体超压色标
    add_fluid_pressure_colorbar(fig)
    
    # 添加标题
    ax.set_title(f'Vp/Vs Profile from ({lonA:.3f}°E, {latA:.3f}°N) to ({lonB:.3f}°E, {latB:.3f}°N)', 
                 fontsize=16, fontweight='bold', pad=20)
    
    return fig, ax


def preprocess_data(lon, lat, dep, val):
    """数据预处理和质量控制"""
    # 1. 去除异常值（使用IQR方法）
    q1, q3 = np.percentile(val, [25, 75])
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr
    
    # 但对于Vp/Vs，我们知道合理范围，所以使用物理约束
    mask = (val >= 1.5) & (val <= 2.0)  # Vp/Vs的合理范围
    
    lon = lon[mask]
    lat = lat[mask]
    dep = dep[mask]
    val = val[mask]
    
    # 2. 数据去重和平均
    coords = np.round(np.column_stack([lon, lat, dep]), decimals=5)
    unique_coords, inverse_indices = np.unique(coords, axis=0, return_inverse=True)
    
    averaged_values = np.zeros(len(unique_coords))
    for i in range(len(unique_coords)):
        averaged_values[i] = np.mean(val[inverse_indices == i])
    
    return (unique_coords[:, 0], unique_coords[:, 1], 
            unique_coords[:, 2], averaged_values)


def select_profile_data(lon, lat, lonA, latA, lonB, latB, buffer_km):
    """选择剖面附近的数据点"""
    # 剖面方向向量
    profile_vec = np.array([lonB - lonA, latB - latA])
    profile_length = np.linalg.norm(profile_vec)
    profile_unit = profile_vec / profile_length
    
    # 垂直于剖面的单位向量
    perp_unit = np.array([-profile_unit[1], profile_unit[0]])
    
    selected_indices = []
    for i in range(len(lon)):
        point_vec = np.array([lon[i] - lonA, lat[i] - latA])
        
        # 投影距离（沿剖面方向）
        proj_dist = np.dot(point_vec, profile_unit)
        
        # 垂直距离
        perp_dist = abs(np.dot(point_vec, perp_unit))
        perp_dist_km = perp_dist * 111  # 近似转换为km
        
        # 检查是否在剖面范围内且在缓冲区内
        if (0 <= proj_dist <= profile_length) and (perp_dist_km <= buffer_km):
            selected_indices.append(i)
    
    return np.array(selected_indices)


def perform_improved_interpolation(lon, lat, dep, val, lon_grid, lat_grid, dep_grid):
    """执行改进的3D插值"""
    points = np.column_stack([lon, lat, dep])
    xi = np.column_stack([lon_grid.flatten(), lat_grid.flatten(), dep_grid.flatten()])
    
    try:
        # 首选方法：径向基函数插值（RBF）
        print("使用RBF插值...")
        # 对数据进行归一化以提高数值稳定性
        lon_norm = (lon - lon.mean()) / lon.std()
        lat_norm = (lat - lat.mean()) / lat.std()
        dep_norm = (dep - dep.mean()) / dep.std()
        
        lon_grid_norm = (lon_grid.flatten() - lon.mean()) / lon.std()
        lat_grid_norm = (lat_grid.flatten() - lat.mean()) / lat.std()
        dep_grid_norm = (dep_grid.flatten() - dep.mean()) / dep.std()
        
        rbf = Rbf(lon_norm, lat_norm, dep_norm, val, 
                  function='multiquadric', epsilon=0.5, smooth=0.1)
        V = rbf(lon_grid_norm, lat_grid_norm, dep_grid_norm)
        V = V.reshape(dep_grid.shape)
        
    except Exception as e:
        print(f"RBF插值失败: {e}")
        print("退回到griddata插值...")
        # 备选方法：使用griddata
        V = griddata(points, val, xi, method='linear', fill_value=np.nan)
        
        # 填充NaN值
        if np.any(np.isnan(V)):
            V_nearest = griddata(points, val, xi, method='nearest')
            V[np.isnan(V)] = V_nearest[np.isnan(V)]
        
        V = V.reshape(dep_grid.shape)
    
    # 确保值在合理范围内
    V = np.clip(V, 1.5, 2.0)
    
    return V


def adaptive_smoothing(V, depth_grid):
    """深度自适应的平滑处理"""
    V_smooth = np.zeros_like(V)
    
    for i in range(V.shape[0]):
        # 浅部使用较小的平滑参数，深部使用较大的平滑参数
        depth = abs(depth_grid[i, 0])
        
        # 平滑参数随深度线性增加
        if depth < 5:
            sigma = 0.5
        elif depth < 15:
            sigma = 0.5 + (depth - 5) / 10 * 1.0
        else:
            sigma = 1.5 + (depth - 15) / 10 * 0.5
        
        # 应用一维高斯滤波
        V_smooth[i, :] = gaussian_filter(V[i, :], sigma=sigma)
    
    # 垂直方向也进行轻微平滑
    for j in range(V.shape[1]):
        V_smooth[:, j] = gaussian_filter(V_smooth[:, j], sigma=0.3)
    
    return V_smooth


def calculate_profile_distance(lonA, latA, lons, lats):
    """计算沿剖面的大圆距离"""
    R = 6371  # 地球半径 (km)
    
    phi1 = np.radians(latA)
    lam1 = np.radians(lonA)
    phi2 = np.radians(lats)
    lam2 = np.radians(lons)
    
    # 大圆距离公式
    cosang = np.sin(phi1) * np.sin(phi2) + \
             np.cos(phi1) * np.cos(phi2) * np.cos(lam2 - lam1)
    cosang = np.clip(cosang, -1, 1)
    dist = R * np.arccos(cosang)
    
    return dist


def create_custom_colormap():
    """创建自定义色标"""
    # 红色到蓝色的渐变色标（更平滑的过渡）
    colors = [
        '#800000',  # 深红
        '#CC0000',  # 红
        '#FF0000',  # 纯红
        '#FF4500',  # 橙红
        '#FFA500',  # 橙
        '#FFFF00',  # 黄
        '#00FF00',  # 绿
        '#00CED1',  # 深青
        '#0000FF',  # 蓝
        '#000080',  # 深蓝
    ]
    
    n_bins = 256
    cmap = LinearSegmentedColormap.from_list('vp_vs_red_blue', colors, N=n_bins)
    
    return cmap


def add_fluid_pressure_events(ax, fluid_file, lonA, latA, lonB, latB, max_d):
    """添加流体超压地震事件"""
    try:
        print("读取流体超压地震数据...")
        Ff = np.loadtxt(fluid_file)
        
        if Ff.shape[1] >= 8:
            # 筛选条件
            mask = (Ff[:, 6] >= 10) & (Ff[:, 7] < 3)
            lon_hp = Ff[mask, 1]
            lat_hp = Ff[mask, 0]
            dep_hp = Ff[mask, 2]
            p_hp = Ff[mask, 6]
            
            if len(lon_hp) > 0:
                pressure_min = 10
                pressure_max = 50
                
                # 计算剖面方向向量
                lv = np.array([lonB - lonA, latB - latA])
                lv_norm = lv / np.linalg.norm(lv)
                
                # 投影地震到剖面上
                for i in range(len(lon_hp)):
                    vec_i = np.array([lon_hp[i] - lonA, lat_hp[i] - latA])
                    proj_dist = np.dot(vec_i, lv_norm) * max_d / np.linalg.norm(lv)
                    
                    # 计算垂直距离
                    perp_vec = vec_i - np.dot(vec_i, lv_norm) * lv_norm
                    perp_dist_km = np.linalg.norm(perp_vec) * 111
                    
                    # 只绘制在剖面10km范围内的点
                    if 0 <= proj_dist <= max_d and perp_dist_km <= 10:
                        # 计算颜色（白→深绿渐变）
                        frac = (p_hp[i] - pressure_min) / (pressure_max - pressure_min)
                        frac = np.clip(frac, 0, 1)
                        
                        # 使用白色到深绿色的渐变
                        # RGB: 白色(1,1,1) → 深绿色(0,0.4,0)
                        r = 1 - frac
                        g = 1 - 0.6 * frac
                        b = 1 - frac
                        color = (r, g, b)
                        
                        # 根据压力大小调整点的大小
                        size = 4 + frac * 6
                        
                        # 绘制地震点
                        ax.plot(proj_dist, -dep_hp[i], 'o', 
                               markersize=size,
                               markeredgecolor='black', 
                               markerfacecolor=color,
                               markeredgewidth=0.5,
                               alpha=0.9)
                
                print(f"绘制了 {len(lon_hp)} 个流体超压地震事件")
                
    except Exception as e:
        print(f"读取或绘制流体数据时出错: {e}")


def add_fluid_pressure_colorbar(fig):
    """添加流体超压色标"""
    try:
        # 创建第二个轴用于流体压力色标
        ax2 = fig.add_axes([0.88, 0.15, 0.02, 0.75])
        
        # 创建渐变
        pressure_min = 10
        pressure_max = 50
        gradient = np.linspace(0, 1, 256).reshape(256, 1)
        
        # 创建白色到深绿色的自定义色标
        from matplotlib.colors import LinearSegmentedColormap
        colors_fluid = [(0, 0.4, 0),(1, 1, 1)]  # 白色到深绿色
        n_bins = 256
        cmap_fluid = LinearSegmentedColormap.from_list('white_green', colors_fluid, N=n_bins)
        
        ax2.imshow(gradient, aspect='auto', cmap=cmap_fluid,
                  extent=[0, 1, pressure_min, pressure_max])
        
        ax2.set_xticks([])
        ax2.set_ylabel('Excess Fluid Pressure (MPa)', fontsize=12, fontweight='bold')
        ax2.yaxis.set_label_position('right')
        ax2.yaxis.tick_right()
        ax2.tick_params(axis='y', which='major', labelsize=10)
        
        # 添加边框
        for spine in ax2.spines.values():
            spine.set_edgecolor('black')
            spine.set_linewidth(1)
        
    except Exception as e:
        print(f"添加流体压力色标时出错: {e}")